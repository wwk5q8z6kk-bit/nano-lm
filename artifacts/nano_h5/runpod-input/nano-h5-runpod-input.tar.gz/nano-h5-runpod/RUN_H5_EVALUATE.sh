#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export PYTHONHASHSEED=0
cleanup() {
  rm -f -- 'SHA256SUMS.tmp' 'nano-h5-results.tar.gz.tmp' 'nano-h5-results.tar.gz.sha256.tmp'
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
trap 'exit 129' HUP

test -f results/TRAINING_REPORT_SHA256SUMS
test ! -L results/TRAINING_REPORT_SHA256SUMS
test ! -e results/development_evaluation.json
test -x .h5-venv/bin/python
export PATH="$PWD/.h5-venv/bin:$PATH"
sha256sum -c results/TRAINING_REPORT_SHA256SUMS
test -f h2_development/manifest.json
test ! -L h2_development/manifest.json
test -f h2_development/dev.jsonl
test ! -L h2_development/dev.jsonl
test "$(sha256sum h2_development/manifest.json | awk '{print $1}')" = "47ee157ac037c0771100b8546c90da91dbd2006198700bb642f1561d2124c1a3"
test "$(sha256sum h2_development/dev.jsonl | awk '{print $1}')" = "9c893d8e64110287b433d567e0e9abb42c611ecba33b40de192741324d37e290"

report_a_sha="$(sha256sum results/seed-20260805/training_report.json | awk '{print $1}')"
report_b_sha="$(sha256sum results/seed-20260806/training_report.json | awk '{print $1}')"
python -m nano_ai.training.evaluate_evidence_query_h5 --training-data-dir h5_data --training-manifest-sha256 2569e7b27b53ef741fc92d1545ca323367155d960e77ff0e6852b32db0d32f31 --development-data-dir h2_development --development-manifest-sha256 47ee157ac037c0771100b8546c90da91dbd2006198700bb642f1561d2124c1a3 --tokenizer sft/tokenizer.json --training-report results/seed-20260805/training_report.json "$report_a_sha" --training-report results/seed-20260806/training_report.json "$report_b_sha" --output results/development_evaluation.json --device cuda --batch-size 32 2>&1 | tee results/development_evaluation.log

find results -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS.tmp
mv SHA256SUMS.tmp results/SHA256SUMS
tar -czf nano-h5-results.tar.gz.tmp results
mv nano-h5-results.tar.gz.tmp nano-h5-results.tar.gz
sha256sum nano-h5-results.tar.gz > nano-h5-results.tar.gz.sha256.tmp
mv nano-h5-results.tar.gz.sha256.tmp nano-h5-results.tar.gz.sha256
trap - EXIT INT TERM HUP
