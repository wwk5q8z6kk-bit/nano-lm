#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export PYTHONHASHSEED=0

test ! -e results
test ! -e h2_development
test ! -e .h4-venv
test "$(sha256sum h4_data/manifest.json | awk '{print $1}')" = "444c5d6dcb613959a28ee3ce2e1dd7e25e2fabc2603ba4192d445ed3bedb406f"
python -m venv --system-site-packages .h4-venv
export PATH="$PWD/.h4-venv/bin:$PATH"
python -m pip install --disable-pip-version-check --no-cache-dir -r requirements-h4-runpod.txt
python -c 'import platform, torch, tokenizers; assert platform.python_version().startswith("3.12."); assert torch.__version__ == "2.8.0+cu128"; assert torch.version.cuda == "12.8"; assert tokenizers.__version__ == "0.22.2"; assert torch.cuda.is_available(); assert torch.cuda.get_device_name(0) == "NVIDIA GeForce RTX 5090"; assert torch.cuda.get_device_properties(0).total_memory >= 20 * 1024**3'
python -m pytest -q nano_ai/tests/test_surface_transfer_data.py nano_ai/tests/test_train_evidence_query_h4.py nano_ai/tests/test_evaluate_evidence_query_h4.py nano_ai/tests/test_package_evidence_query_h4.py

mkdir results
python -m nano_ai.training.train_evidence_query_h4 --data-dir h4_data --base-checkpoint checkpoints/anchors/nano_v01_scribe.pt --tokenizer sft/tokenizer.json --output-dir results/seed-20260805 --seed 20260805 --device cuda 2>&1 | tee results/seed-20260805.log
python -m nano_ai.training.train_evidence_query_h4 --data-dir h4_data --base-checkpoint checkpoints/anchors/nano_v01_scribe.pt --tokenizer sft/tokenizer.json --output-dir results/seed-20260806 --seed 20260806 --device cuda 2>&1 | tee results/seed-20260806.log

sha256sum results/seed-20260805/training_report.json results/seed-20260806/training_report.json > results/TRAINING_REPORT_SHA256SUMS
